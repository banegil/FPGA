
#include <string>
#include <iostream>
#include <fstream>
#include <mutex>
#include <ctime>

using namespace std;

mutex mtxLog, mtxStd;
    
void writte_log(const string& s){
      mtxLog.lock();
        time_t now = time(0);
        char* dt = ctime(&now);
        mtxStd.lock();
          cout << dt << " " << s << '\n';
        mtxStd.unlock();
        ofstream output("logg.txt", std::ios::app);
        output << dt << " " << s << '\n';
        output.close();
      mtxLog.unlock();
}

void writte_arb(const string& s){
        time_t now = time(0);
        char* dt = ctime(&now);
        mtxStd.lock();
          cout << dt << " " << s << '\n';
        mtxStd.unlock();
        ofstream output("arb.txt", std::ios::app);
        output << dt << " " << s << '\n';
        output.close();
}

