

class Huobi: public Exchange {
    mutex mtxDepth;
    map < string, map <double,double> >  depth;
    
    public:
    Huobi(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        int i;
        Json::Value result; 
        map < string, map <double,double> >  depthCache;
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        transform(symbol.begin(), symbol.end(), symbol.begin(),
        [](unsigned char c){ return tolower(c); });
        string s = "https://api-aws.huobi.pro/market/depth?symbol=" + symbol + "&type=step3";
        get_curl(s, result);
     	
     	if(result.isMember("tick") && result["tick"].isMember("bids")){	
	        for ( int i = 0 ; i < result["tick"]["asks"].size(); i++ ) {
		        double price = atof( result["tick"]["asks"][i][0].asString().c_str() );
		        double qty   = atof( result["tick"]["asks"][i][1].asString().c_str() );
		        depthCache["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["tick"]["bids"].size() ; i++ ) {
		        double price = atof( result["tick"]["bids"][i][0].asString().c_str() );
		        double qty   = atof( result["tick"]["bids"][i][1].asString().c_str() );
		        depthCache["bids"][price] = qty;
	        }
	    }
	    else
	        writte_log( "ERROR: <curl_depth> Huobi: " + symbol );
	    
	    return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){
        int i, j;
        time_t current_time; 
        init_http("api.huobi.pro");
        string symbol2 = symbol;
        int timestamp = 0;
        
        try {
            symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
            transform(symbol.begin(), symbol.end(), symbol.begin(),
            [](unsigned char c){ return tolower(c); });
            init_webSocket("api.huobi.pro", "443", "/ws");
            string s = "{\"sub\": \"market." + symbol + ".depth.step0\",\"id\": \"id1\"}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value json_result;
		    for(int i = 0; i < 2; i++){
                read_Socket();	
                s = decompress_gzip(get_socket_data());
		        reader.parse( s , json_result );
                buffer_clear();
            }
            
            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                Json::Reader reader;
		        Json::Value json_result;
                read_Socket();	
                s = decompress_gzip(get_socket_data());
		        reader.parse( s , json_result );
                buffer_clear();
                
                mtxDepth.lock();
                
                if(ct2 - ct > TIME_REFRESH) {
                    ct = ct2;
                    depth.clear();
                    depth = curl_depth(symbol2);
                }
                if(json_result.isMember("tick")){
             	    int ts = json_result["ts"].asUInt64();
             	    if(ts > timestamp){
             	        timestamp = ts;
                
                        if(json_result["tick"].isMember("bids")){
                            for ( i = 0 ; i < json_result["tick"]["bids"].size() ; i++ ) {
                                double price = atof( json_result["tick"]["bids"][i][0].asString().c_str());
                                double qty 	 = atof( json_result["tick"]["bids"][i][1].asString().c_str());
                                if ( qty == 0.0 ) {
                                    depth["bids"].erase(price);
                                } else {
                                    depth["bids"][price] = qty;
                                }
                            }
                        }
                        if(json_result["tick"].isMember("asks")){
                            for ( i = 0 ; i < json_result["tick"]["asks"].size() ; i++ ) {
                                double price = atof( json_result["tick"]["asks"][i][0].asString().c_str());
                                double qty 	 = atof( json_result["tick"]["asks"][i][1].asString().c_str());
                                if ( qty == 0.0 ) {
                                    depth["asks"].erase(price);
                                } else {
                                    depth["asks"][price] = qty;
                                }
                            }
                        }
                    }
                }
                else {
                    j = json_result["ping"].asUInt64();
                    s = "{\"pong\": " + to_string(j) + "}";
                    write_Socket(s);
                }
                
                cout << json_result << endl;
                    
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
    void send_order( string symbol, string side, double quantity, double price ) {	
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        transform(symbol.begin(), symbol.end(), symbol.begin(),
        [](unsigned char c){ return tolower(c); });
        string post_data = createSignatureParamHuobi();
        Json::Value json_result;
        string err;

        string url("https://api.huobi.pro/v1/order/orders/place?");
        string action = "POST";
        
        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        string str_result;
        url += post_data;
        string body = "{\"account-id\":\"48038614\",\"symbol\":\"" + symbol + "\",\"type\":\"" + side + "-market\",\"amount\":\"" + to_string(quantity) + "\"}";
        curl_api_with_header( url, str_result , extra_http_header, body, action) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Huobi: error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Huobi: order.size() is 0";
            writte_log(err);
        }
    }
   
   map < string, map <double,double> > get_socketDepth(){
        mtxDepth.lock();
        map < string, map <double,double> > d = depth;
        mtxDepth.unlock();
        return d;
   }
};

