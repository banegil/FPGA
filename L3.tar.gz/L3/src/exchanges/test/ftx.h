#include "exchange.h"

class Ftx: public Exchange {
    mutex mtxDepth;
    map < string, map <double,double> >  depth;
    
    public:
    Ftx(const int& id, string &api_key, string &secret_key) : Exchange(id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        int i;
        Json::Value result; 
        map < string, map <double,double> >  depthCache;
        
        symbol[symbol.find('-')] = '/';
        string s = "https://ftx.com/api/markets/" + symbol + "/orderbook?depth=100";
        get_curl(s, result);
     	
     	if(result.isMember("result") && result["result"].isMember("asks")){	
	        for ( int i = 0 ; i < result["result"]["asks"].size(); i++ ) {
		        double price = atof( result["result"]["asks"][i][0].asString().c_str() );
		        double qty   = atof( result["result"]["asks"][i][1].asString().c_str() );
		        depthCache["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["result"]["bids"].size() ; i++ ) {
		        double price = atof( result["result"]["bids"][i][0].asString().c_str() );
		        double qty   = atof( result["result"]["bids"][i][1].asString().c_str() );
		        depthCache["bids"][price] = qty;
	        }
	    }
	    else
	        cout << "ERROR" << endl;
	    
	    return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){  
        depth = curl_depth(symbol);
        init_http("ftx.com");
        
        try {
            init_webSocket("ftx.com", "443",  "/ws/");
            string s = "{\"op\": \"subscribe\", \"channel\": \"orderbook\", \"market\": \"" + symbol + "\"}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value result;

	            read_Socket();	
		        reader.parse( get_socket_data() , result );
                buffer_clear();
            
            cout << result << endl;
            
            /*if(result.isMember("params") && result["params"][1].isMember("asks")){	
	            for ( int i = 0 ; i < result["params"][1]["asks"].size(); i++ ) {
		            double price = atof( result["params"][1]["asks"][i][0].asString().c_str() );
		            double qty   = atof( result["params"][1]["asks"][i][1].asString().c_str() );
		            depth["asks"][price] = qty;
	            }
	            for  ( int i = 0 ; i < result["params"][1]["bids"].size() ; i++ ) {
		            double price = atof( result["params"][1]["bids"][i][0].asString().c_str() );
		            double qty   = atof( result["params"][1]["bids"][i][1].asString().c_str() );
		            depth["bids"][price] = qty;
		        }
	        }
	        else
	            cout << "ERROR1" << endl;*/

            while (true) {
                read_Socket();	
		        reader.parse( get_socket_data() , result );
                buffer_clear();
                
                mtxDepth.lock();

                /*if(result.isMember("params") && result["params"][1].isMember("asks")){	
	                for ( int i = 0 ; i < result["params"][1]["asks"].size(); i++ ) {
		                double price = atof( result["params"][1]["asks"][i][0].asString().c_str() );
		                double qty   = atof( result["params"][1]["asks"][i][1].asString().c_str() );
		                if ( qty == 0.0 ) 
			                depth["asks"].erase(price);
		                else 
			                depth["asks"][price] = qty;
	                }
	                for  ( int i = 0 ; i < result["params"][1]["bids"].size() ; i++ ) {
		                double price = atof( result["params"][1]["bids"][i][0].asString().c_str() );
		                double qty   = atof( result["params"][1]["bids"][i][1].asString().c_str() );
		                if ( qty == 0.0 ) 
			                depth["bids"].erase(price);
		                else 
			                depth["bids"][price] = qty;
		            }
	            }
	            else {
                    cout << "ERROR2" << endl;
                }*/
                
                cout << result << endl;
                    
                while(150 < depth["bids"].size())
                    depth["bids"].erase( prev( depth["bids"].end() ) );
                while(150 < depth["asks"].size())
                    depth["asks"].erase( prev( depth["asks"].end() ) );
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
            cout << "ERROR: " << e.what() << endl;
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        mtxDepth.lock();
        map < string, map <double,double> > d = depth;
        mtxDepth.unlock();
        return d;
   }
};
