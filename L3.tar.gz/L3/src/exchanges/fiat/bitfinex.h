
class Bitfinex: public Exchange {
    mutex mtxDepth;
    map < string, map <double,double> >  depth;
    string api_key = "p3tVsBKJbz66VUOdhcZQxZhUs1lcRvkosj64MyM8Yet";
    string secret_key = "eDeR6XLtOQaPE9yjIejXKh2GRcH11MJmzJYEb8ftnBC";
    
    public:
    Bitfinex(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    map < string, map <double,double> > curl_depth(string symbol){
        int i;
        Json::Value result; 
        map < string, map <double,double> >  depthCache;
        
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string s = "https://api-pub.bitfinex.com/v2/book/t" + symbol + "/R0";
        get_curl(s, result);
     	
     	if(result.isArray()){
            for ( i = 0 ; i < 25; i++ ) {
	            double price = result[i][0].asDouble();
	            double qty   = result[i][2].asDouble();
	            depthCache["bids"][price] = qty;
            }
            for  ( i = 25 ; i < 50; i++ ) {
	            double price = result[i][0].asDouble();
	            double qty   = result[i][2].asDouble();
	            depthCache["asks"][price] = qty * -1;
            }
        }
        else
            writte_log( "ERROR: <curl_depth> Bitfinex: " + symbol );
	    
	    return depthCache;
    }
    
    void wesbsocketInit_depth(string symbol){
        map < string, double >  idPrice;
        time_t current_time; 
        init_http("api-pub.bitfinex.com");
        
        try {
            symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
            init_webSocket("api-pub.bitfinex.com", "443", "/ws/2");
            string s = "{ \"event\": \"subscribe\", \"channel\": \"book\", \"prec\": \"R0\", \"symbol\": \"t" + symbol + "\" }";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value json_result;
		    for(int i = 0; i < 3; i++){
                read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
            }
            
            mtxDepth.lock();
            if(json_result.isArray()){
                for ( int i = 0; i < json_result[1].size(); i++ ) {
                    double price;
                    if(json_result[1][i][2] < 0){
                        price = json_result[1][i][1].asDouble();
                        double qty 	 = json_result[1][i][2].asDouble();
                        depth["asks"][price] = qty;
                    }
                    else{
                        price = json_result[1][i][1].asDouble();
                        double qty 	 = json_result[1][i][2].asDouble();
                        depth["bids"][price] = qty;
                    }
                    idPrice[json_result[1][i][0].asString()] = price;
                }
            }
            else 
                writte_log( "ERROR: <wss_depth> Bitfinex: " + symbol );
            mtxDepth.unlock();
            
            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                Json::Reader reader;
		        Json::Value json_result;
                read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
                
                mtxDepth.lock();
                
                if(ct2 - ct >= 70){
                    ct = ct2;
                    depth.clear();
                    idPrice.clear();
                    depth = curl_depth(symbol);
                }
                else if (json_result.isArray() && json_result[1].isArray()) {
                    if(atoi( json_result[1][2].asString().c_str()) < 0){
                        double price = atof( json_result[1][1].asString().c_str());
                        double qty 	 = atof( json_result[1][2].asString().c_str());
                        if ( price == 0.0 ) {
                            depth["asks"].erase(idPrice[json_result[1][0].asString()]);
                        } else {
                            depth["asks"][price] = qty;
                            idPrice[json_result[1][0].asString()] = price;
                        }
                    }
                    else{
                        double price = atof( json_result[1][1].asString().c_str());
                        double qty 	 = atof( json_result[1][2].asString().c_str());
                        if ( price == 0.0 ) {
                            depth["bids"].erase(idPrice[json_result[1][0].asString()]);
                        } else {
                            depth["bids"][price] = qty;
                            idPrice[json_result[1][0].asString()] = price;
                        }
                    }
                }
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
    void send_order( string symbol, string side, double quantity, double price ) {	
        Json::Value json_result;
        string err;

        string ep = to_string (get_current_ms_epoch());

        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string url("https://api.bitfinex.com/v2/auth/w/order/submit");
        string action = "POST";
        
        // BUY?? SELL??
        string post_data = "{\"type\":\"MARKET\",\"symbol\":\"t" + symbol + "\",\"amount\":\"" + to_string (quantity) + "\"}";
        string msg = "/api/v2/auth/w/order/submit" + ep + "{\"type\":\"MARKET\",\"symbol\":\"t" + symbol + "\",\"amount\":\"" + to_string (quantity) + "\"}";
        
        string signature = hmac_sha384( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="bfx-nonce:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "bfx-apikey:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "bfx-signature:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;
        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Bitfinex: error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Bitfinex: order.size() is 0";
            writte_log(err);
        }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        mtxDepth.lock();
        map < string, map <double,double> > d = depth;
        mtxDepth.unlock();
        return d;
   }
};
