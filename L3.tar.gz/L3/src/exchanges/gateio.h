

class Gateio: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
/*  
    old:  
    string api_key = "AFBFF04D-7362-482C-8176-A68D594F394A";
    string secret_key = "59eb2407dc7e9f9d51b35d3525ef71cc7b8034704a375c96660d30de74b704bd";
*/  
    string api_key = "d12c6b411de430840c474455e25285fd";
    string secret_key = "d7ae70d34d768d9a140ed6b61ae8f31b281e0f1b006762b4ee9f21c4f52e0460";
    
    
    public:
    Gateio(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        int i;
        Json::Value result; 
        
        symbol[symbol.find('-')] = '_';
        string s = "https://api.gateio.ws/api/v4/spot/order_book?currency_pair=" + symbol + "&limit=50";
        mtxCurl.lock();
        get_curl(s, result);
        mtxCurl.unlock();
     	
     	mtxDepth.lock();     
     	
     	depth.clear(); 
     	if(result.isMember("asks") && result.isMember("bids")){	
	        for ( int i = 0 ; i < result["asks"].size(); i++ ) {
		        double price = atof( result["asks"][i][0].asString().c_str() );
		        double qty   = atof( result["asks"][i][1].asString().c_str() );
		        depth["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["bids"].size() ; i++ ) {
		        double price = atof( result["bids"][i][0].asString().c_str() );
		        double qty   = atof( result["bids"][i][1].asString().c_str() );
		        depth["bids"][price] = qty;
	        }
	    }
	    else
	        writte_log( "ERROR: <curl_depth> Gateio: " + symbol ); 

        mtxDepth.unlock();     
    }
    
    void wesbsocketInit_depth(string symbol){
        time_t current_time; 
        int i, lastUpdateId = 0;
        init_http("ws.gate.io");
        int timestamp = 0;
        
        try {
            string symbol2 = symbol;
            symbol[symbol.find('-')] = '_';
            init_webSocket("ws.gate.io", "443", "/v3");
            string s = "{\"id\":12312, \"method\":\"depth.subscribe\", \"params\":[\"" + symbol + "\", 30, \"0\"]}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value json_result;
            read_Socket();	
		    reader.parse( get_socket_data() , json_result );
            buffer_clear();
            
            time(&current_time);
            int ct = current_time;
            //long nn, n;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                Json::Reader reader;
		        Json::Value json_result;
                read_Socket();	
			    reader.parse( get_socket_data() , json_result );
                buffer_clear();
                
                /*
                if(json_result.isMember("error")){
                    nn = get_current_ms_epoch();
                    cout << nn - n << endl;
                }
                if(ct2 - ct > 4){ 
                    ct = ct2;
                    n = get_current_ms_epoch();
                    write_Socket(R"({"time" : 123456, "channel" : "futures.ping"})"); 
                }
                */
                
                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    std::async (&Gateio::curl_depth, this, symbol2);
                }
                
                mtxDepth.lock();               

                if(json_result["params"][1].isMember("bids")){
                    for ( i = 0 ; i < json_result["params"][1]["bids"].size() ; i++ ) {
                        double price = atof( json_result["params"][1]["bids"][i][0].asString().c_str());
                        double qty 	 = atof( json_result["params"][1]["bids"][i][1].asString().c_str());
                        if ( qty == 0.0 ) {
                            depth["bids"].erase(price);
                        } else {
                            depth["bids"][price] = qty;
                        }
                    }
                }
                if(json_result["params"][1].isMember("asks")){
                    for ( i = 0 ; i < json_result["params"][1]["asks"].size() ; i++ ) {
                        double price = atof( json_result["params"][1]["asks"][i][0].asString().c_str());
                        double qty 	 = atof( json_result["params"][1]["asks"][i][1].asString().c_str());
                        if ( qty == 0.0 ) {
                            depth["asks"].erase(price);
                        } else {
                            depth["asks"][price] = qty;
                        }
                    }
                }
                    
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
    void send_order( string symbol, string side, double quantity, double price ) {	
        time_t current_time;
        Json::Value json_result;
        string err;

        int t = time(&current_time);
        string ep = to_string(t);

        symbol[symbol.find('-')] = '_';
        string url("https://api.gateio.ws/api/v4/spot/orders");
        string action = "POST";
        
        string_toupper(side);
        string post_data = "{\"currency_pair\":\"" + symbol + "\",\"account\":\"spot\",\"side\":\"" + side + "\",\"amount\":\"" + to_string(quantity) + "\",\"price\":\"" + to_string(price) + "\"}";
        string msg = action + "\n" + "/api/v4/spot/orders" + "\n" + "\n" + sha512( post_data.c_str() ) + "\n" + ep;
        
        string signature =  hmac_sha512( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="KEY:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "Timestamp:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "SIGN:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;

        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Gateio: send_order(), error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Gateio: send_order(), order.size() is 0";
            writte_log(err);
        }
   }
   
    void withdraw( string coin, string address, double amount, string network ) {	
        time_t current_time;
        Json::Value json_result;
        string err;

        int t = time(&current_time);
        string ep = to_string(t);

        string url("https://api.gateio.ws/api/v4/withdrawals");
        string action = "POST";
        
        string post_data = "{\"currency\":\"USDT\",\"address\":\"1HkxtBAMrA3tP5ENnYY2CZortjZvFDH5Cs\",\"amount\":\"222.61\",\"memo\":\"\",\"chain\":\"TRX\"}";
        string msg = action + "\n" + "/api/v4/withdrawals" + "\n" + "\n" + sha512( post_data.c_str() ) + "\n" + ep;
        
        string signature =  hmac_sha512( secret_key.c_str(), msg.c_str() );
        
        vector <string> extra_http_header;
        string header_chunk="Accept: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="Content-Type: application/json";
        extra_http_header.push_back(header_chunk);
        header_chunk="KEY:";
        header_chunk.append( api_key );
        extra_http_header.push_back(header_chunk);
        header_chunk = "Timestamp:";
        header_chunk.append( ep );
        extra_http_header.push_back(header_chunk);
        header_chunk = "SIGN:";
        header_chunk.append( signature );
        extra_http_header.push_back(header_chunk);
        
        string str_result;

        curl_api_with_header( url, str_result , extra_http_header, post_data, action ) ;

        if ( str_result.size() > 0 ) {
            try {
	            Json::Reader reader;
	            json_result.clear();	
	            reader.parse( str_result , json_result );
	            cout << json_result << endl;
            		
            	} catch ( exception &e ) {
             	    err = "Gateio: withdraw(), error reading order response, ";
             	    err.append( e.what() );
                    writte_log(err);
            }   
        } 
        else {
            err = "Gateio: withdraw(), order.size() is 0";
            writte_log(err);
        }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
