

class Poloniex: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    
    public:
    Poloniex(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        int i;
        Json::Value result; 
        
        string s2 = symbol.substr(symbol.find('-') + 1, symbol.length() - 1) + "_" + symbol.substr(0, symbol.find('-'));
        string s = "https://poloniex.com/public?command=returnOrderBook&currencyPair=" + s2 + "&depth=50";
        mtxCurl.lock();
        get_curl(s, result);
        mtxCurl.unlock();
     	
     	mtxDepth.lock();
     	
     	if(result.isMember("asks") && result.isMember("bids")){	
	        for ( int i = 0 ; i < result["asks"].size(); i++ ) {
		        double price = atof( result["asks"][i][0].asString().c_str() );
		        double qty   = atof( result["asks"][i][1].asString().c_str() );
		        depth["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["bids"].size() ; i++ ) {
		        double price = atof( result["bids"][i][0].asString().c_str() );
		        double qty   = atof( result["bids"][i][1].asString().c_str() );
		        depth["bids"][price] = qty;
	        }
	    }
	    else
	        writte_log( "ERROR: <curl_depth> Poloniex: " + symbol );
	    
        mtxDepth.unlock();
    }
    
    void wesbsocketInit_depth(string symbol){
        int i;
        string j;
        time_t current_time; 
        curl_depth(symbol);
        init_http("api2.poloniex.com");
        int timestamp = 0;
        
        try {
            string symbol2 = symbol;
            string s2 = symbol.substr(symbol.find('-') + 1, symbol.length() - 1) + "_" + symbol.substr(0, symbol.find('-'));
            init_webSocket("api2.poloniex.com", "443", "/");
            string s = "{\"command\": \"subscribe\", \"channel\": \"" + s2 + "\"}";
            write_Socket(s);
            Json::Reader reader;
		    Json::Value json_result;
		    for(int i = 0; i < 2; i++){
		        read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
		    }

            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                Json::Reader reader;
		        Json::Value json_result;
                read_Socket();	
		        reader.parse( get_socket_data() , json_result );
                buffer_clear();
                
                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    std::async (&Poloniex::curl_depth, this, symbol2);
                }
                
                mtxDepth.lock();

                if(json_result[0].asUInt64() != 1010){
                    int ts = json_result[1].asUInt64();
             	    if(ts > timestamp){
             	        timestamp = ts;
             	        
                        if(json_result[2][0][1].asUInt64() == 1){
                            double price = atof( json_result[2][0][2].asString().c_str());
                            double qty 	 = atof( json_result[2][0][3].asString().c_str());
                            if ( qty == 0.0 ) {
                                depth["bids"].erase(price);
                            } else {
                                depth["bids"][price] = qty;
                            }
                        }
                        if(json_result[2][0][1].asUInt64() == 0){
                            double price = atof( json_result[2][0][2].asString().c_str());
                            double qty 	 = atof( json_result[2][0][3].asString().c_str());
                            if ( qty == 0.0 ) {
                                depth["asks"].erase(price);
                            } else {
                                depth["asks"][price] = qty;
                            }
                        }
                    }
                }

                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
		     	writte_log( err ); 
            return;
          }
   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
