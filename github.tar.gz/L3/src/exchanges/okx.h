class Okx: public Exchange {
    mutex mtxDepth, mtxCurl;
    map < string, map <double,double> >  depth;
    string api_key = "";
    string secret_key = "";
    
    public:
    Okx(const double& fee, const string& id, const string& api_key, const string& secret_key) : Exchange(fee, id, api_key, secret_key) {}
    
    void curl_depth(string symbol){
        Json::Value result; 
        symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
        string s = "https://api.aax.com/v2/market/orderbook?symbol=" + symbol + "&level=50";
        mtxCurl.lock();
        get_curl(s, result);
        mtxCurl.unlock();
     	
        mtxDepth.lock();
     		    
     	if(result.isMember("asks")){	
	        for ( int i = 0 ; i < result["asks"].size(); i++ ) {
		        double price = atof( result["asks"][i][0].asString().c_str() );
		        double qty   = atof( result["asks"][i][1].asString().c_str() );
		        depth["asks"][price] = qty;
	        }
	        for  ( int i = 0 ; i < result["bids"].size() ; i++ ) {
		        double price = atof( result["bids"][i][0].asString().c_str() );
		        double qty   = atof( result["bids"][i][1].asString().c_str() );
		        depth["bids"][price] = qty;
	        }
	    }
	    else
	        writte_log( "ERROR: <curl_depth> Aax: " + symbol );
	 
	    mtxDepth.unlock();
    }
    
    void wesbsocketInit_depth(string symbol){ 
        time_t current_time; 
        init_http("realtime.aax.com");
        curl_depth(symbol);
        int timestamp = 0;
        string symbol2 = symbol;
        
        try {
            symbol.erase(remove(symbol.begin(), symbol.end(), '-'), symbol.end());
            string s = "/marketdata/v2/" + symbol + "@book_50";
            init_webSocket("realtime.aax.com", "443", s.c_str());
            Json::Reader reader;
	        Json::Value result;
	        for(int i = 0; i < 2; i++){
	            read_Socket();	
	            reader.parse( get_socket_data() , result );
                buffer_clear();
            }

            time(&current_time);
            int ct = current_time;
            while (true) {
                time(&current_time);
                int ct2 = current_time;
                Json::Reader reader;
	            Json::Value result;
                read_Socket();	
	            reader.parse( get_socket_data() , result );
                buffer_clear();
                
                if(ct2 - ct > TIME_REFRESH){ 
                    ct = ct2;
                    std::async (&Okx::curl_depth, this, symbol2);
                }
                
                mtxDepth.lock();
                
             	if(result.isMember("t")){	
             	    int ts = result["t"].asUInt64();
             	    if(ts > timestamp){
             	        timestamp = ts;
                 	    
                 	    if(result.isMember("asks")) { 
                            for ( int i = 0 ; i < result["asks"].size(); i++ ) {
                                double price = atof( result["asks"][i][0].asString().c_str() );
                                double qty   = atof( result["asks"][i][1].asString().c_str() );
                                if ( qty == 0.0 ) 
                                    depth["asks"].erase(price);
                                else 
                                    depth["asks"][price] = qty;
                            }
                        }
                        if(result.isMember("bids")) {
                            for  ( int i = 0 ; i < result["bids"].size() ; i++ ) {
                                double price = atof( result["bids"][i][0].asString().c_str() );
                                double qty   = atof( result["bids"][i][1].asString().c_str() );
                                if ( qty == 0.0 ) 
                                    depth["bids"].erase(price);
                                else 
                                    depth["bids"][price] = qty;
                            }
                        }
                   }
                }
                else
                    writte_log( "ERROR: <wss_depth> Aax: " + symbol );
                
                mtxDepth.unlock();
            }
            webSocket_close();
        } catch (std::exception const& e) {
                depth.clear();
                string err = "ERROR: <wss_curl> " + get_id() + ": " + symbol + " " + e.what();
	         	writte_log( err ); 
            return;
          }
    }
   
   void send_order( string symbol, string side, double quantity, double price ) {	

   }
   
   map < string, map <double,double> > get_socketDepth(){
        map < string, map <double,double> > d;
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
   
   map < string, map <double,double> > getget(string symbol){
        map < string, map <double,double> > d;
        curl_depth(symbol);
        mtxDepth.lock();
        d = depth;
        mtxDepth.unlock();
        return d;
   }
};
